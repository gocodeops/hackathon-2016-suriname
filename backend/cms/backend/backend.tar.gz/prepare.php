<?php
    require 'autoload.php';

    $connect = new DatabaseConnector("localhost", "gocodeop_hackathon2016", "gocodeop_hack", ";GiON;]F8JU^");
    $connection = $connect->connect();
?>